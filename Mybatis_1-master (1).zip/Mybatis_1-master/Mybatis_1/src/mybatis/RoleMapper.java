package mybatis;

import src.Role;

public interface RoleMapper {
	public Role getRole(Long id);
}
