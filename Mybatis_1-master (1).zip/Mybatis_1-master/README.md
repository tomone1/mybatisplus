# Mybatis_1

IDE:eclipse

<深入浅出Mybatis技术原理与实战>（杨开振） 第一章源码（抄书，侵删） 

主要内容：JDBC hibernate mybatis的直观观察demo

sql文件也在里面
